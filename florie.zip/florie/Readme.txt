Thanks for downloading this template!

Template Name: Florie
Template URL: https://bootstrapmade.com/Florie-free-bootstrap-cv-resume-html-template/
Author: BootstrapMade.com
License: https://bootstrapmade.com/license/
